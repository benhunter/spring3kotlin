package me.benhunter.spring3kotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Spring3kotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
